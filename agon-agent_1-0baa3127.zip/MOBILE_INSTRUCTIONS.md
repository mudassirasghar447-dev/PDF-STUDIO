# PDF Studio - Mobile APK Build Instructions

This guide will show you how to build and install **PDF Studio** as an Android app (APK) directly from your Android phone, using **only Google Chrome**. You do **NOT** need a computer, laptop, or Android Studio!

We will use **GitHub Codespaces** (a free, web-based coding environment) and **GitHub Actions** (a free cloud builder) to build your APK in the cloud and download it directly to your phone.

---

## Step 1: Download the Project ZIP File
1. In the files panel of this Design Arena workspace, find the file named **`pdf-studio-android.zip`**.
2. Tap on **`pdf-studio-android.zip`** to download it directly to your Android phone's **Downloads** folder.
   *(The file is very small—only about 4 MB—and contains the complete source code, assets, Capacitor configuration, and build workflows!)*

---

## Step 2: Create a Free GitHub Repository
1. Open **Google Chrome** on your Android phone and go to [github.com](https://github.com).
2. Log in to your GitHub account (or sign up for a free account if you don't have one).
3. Tap the **`+`** icon in the top-right corner of the page and select **New repository**.
4. Configure your repository:
   - **Repository name**: Enter `pdf-studio-android`.
   - **Public/Private**: Select **Public** (this ensures that GitHub Actions cloud builds are 100% free and run instantly).
   - **Initialize this repository with**: Do **NOT** select any checkboxes (no README, no .gitignore, no license). Keep it empty.
5. Scroll to the bottom and tap the green **Create repository** button.

---

## Step 3: Upload the Code using GitHub Codespaces (No Computer Needed!)
Since Android browsers cannot easily upload nested folder structures, we will use **GitHub Codespaces**—a free, full terminal and editor that runs right inside your Chrome browser.

1. On your new, empty repository page, look for the **Quick setup** section.
2. Tap the **Code** button (or look for the "Codespaces" tab).
3. Tap the green **Create codespace on main** button.
4. Wait a few seconds for the web-based editor to load in your browser. You will see a workspace that looks like VS Code, complete with a file sidebar and a terminal at the bottom!
5. **Upload your ZIP file**:
   - In the left sidebar explorer, tap the **`...`** (three dots) next to your repository name, or long-press in the empty space of the file explorer.
   - Select **Upload...** from the menu.
   - Choose the **`pdf-studio-android.zip`** file from your phone's **Downloads** folder.
   - Wait for the upload to complete (you will see the file appear in the left sidebar).
6. **Extract and Push the Code**:
   - Tap in the **Terminal** window at the bottom of the screen.
   - Type the following commands one by one and press Enter on your phone keyboard after each:
     ```bash
     # 1. Unzip the project files (this extracts everything into place)
     unzip pdf-studio-android.zip

     # 2. Delete the ZIP file so it doesn't get pushed to GitHub
     rm pdf-studio-android.zip

     # 3. Stage all the extracted files
     git add .

     # 4. Commit the files
     git commit -m "Prepare mobile-only Capacitor APK build"

     # 5. Push the files to GitHub
     git push origin main
     ```
7. Once the push completes, you can close the Codespaces tab!

---

## Step 4: Run the GitHub Actions Build
1. Go back to your repository homepage on [github.com](https://github.com).
2. Tap the **Actions** tab at the top of the page.
3. You will see a workflow run named **"Build Android APK"** has started automatically!
4. Tap on the running workflow (it will have a yellow spinning circle).
5. You can watch the steps compile in real-time! The workflow will:
   - Set up Java 17 and Android SDK.
   - Install npm dependencies.
   - Sync the Capacitor Android project.
   - Compile the Android APK.
6. The build takes about **2 to 3 minutes**. Once it is finished, the circle will turn into a **green checkmark** (Success!).

---

## Step 5: Download the APK to Your Android Phone
1. Tap on the completed **"Build Android APK"** workflow run.
2. Scroll down to the very bottom to find the **Artifacts** section.
3. Tap on the artifact named **`pdf-studio-app`**.
4. Chrome will download a file named `pdf-studio-app.zip` directly to your phone.

---

## Step 6: Install the App on Your Phone
1. Open your phone's file manager (e.g., **Files by Google**, **My Files**, or **ZArchiver**).
2. Go to your **Downloads** folder and find **`pdf-studio-app.zip`**.
3. Tap on it and select **Extract** (or unzip it).
4. Inside the extracted folder, you will see a file named **`app-debug.apk`**.
5. Tap on **`app-debug.apk`** to install it.
6. **If Android blocks the installation**:
   - This is normal for apps installed outside the Google Play Store.
   - Tap **Settings** on the prompt.
   - Turn on **"Allow from this source"** (this gives Chrome or your File Manager permission to install APKs).
   - Go back and tap **Install**.
7. Tap **Open** and enjoy your PDF Studio app! It runs completely offline, meaning your PDFs never leave your device, ensuring 100% privacy.

---

## How to Update the App in the Future
If you want to make changes to the app's HTML, CSS, or JavaScript code:
1. Open your repository's Codespace in Chrome.
2. Make your edits to the files inside the **`site/`** folder.
3. In the terminal, run:
   ```bash
   npx cap sync android
   git add .
   git commit -m "Update app code"
   git push origin main
   ```
4. GitHub Actions will automatically compile a new APK for you! Download and install the new APK to update the app on your phone.
